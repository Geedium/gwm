Cache Extension
===============

This package is a Twig extension that provides integration with the Symfony
Cache component.

It provides a single `cache` tag that allows to cache template fragments.
