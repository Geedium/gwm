Twig Inky Extension
===================

This package is a Twig extension that provides the following:

 * [`inky_to_html`][1] filter: processes an [inky email template](https://github.com/zurb/inky).

[1]: https://twig.symfony.com/inky_to_html
